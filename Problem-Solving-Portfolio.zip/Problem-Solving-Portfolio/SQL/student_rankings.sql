-- Rank students by marks
SELECT name, marks, RANK() OVER (ORDER BY marks DESC) AS rank FROM Students;

-- Average marks by subject
SELECT subject, AVG(marks) FROM Students GROUP BY subject;
