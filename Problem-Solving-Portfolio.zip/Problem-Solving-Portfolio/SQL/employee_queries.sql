-- Get all employees with salary greater than 50000
SELECT * FROM Employees WHERE salary > 50000;

-- Count of employees in each department
SELECT department, COUNT(*) FROM Employees GROUP BY department;
